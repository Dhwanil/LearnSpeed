
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreAudio/CoreAudioTypes.h>

@interface AudioRecorder : UIViewController<AVAudioRecorderDelegate, AVAudioPlayerDelegate>{
    
    AVAudioRecorder *recorder;
	AVAudioSession *session;
    NSTimer *timer;
    NSArray *items;
    BOOL isDelete;
}

@property (retain) AVAudioSession *session;
@property (retain) AVAudioRecorder *recorder;
@property (strong, nonatomic) IBOutlet UILabel *lblTime;
@property (strong, nonatomic) IBOutlet UIButton *btnStart;
@property (strong, nonatomic) IBOutlet UIButton *btnpause;
@property (strong, nonatomic) IBOutlet UIButton *btnStop;


- (IBAction)record:(id)sender;
- (IBAction)pause:(id)sender;
- (IBAction)stop:(id)sender;
- (IBAction)play:(id)sender;
-(void)audioFiles;

- (NSString *)dateString;

@end
