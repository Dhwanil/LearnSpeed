

#import <UIKit/UIKit.h>

@interface StudentInfo : UIViewController

@end
