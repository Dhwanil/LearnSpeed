

#import <UIKit/UIKit.h>

@interface MediaVC : UIViewController<UIActionSheetDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate >{
    UIImagePickerController *imagePicker;
    
}


- (IBAction)record:(id)sender;
-(void)storeImageAtDocDir:(UIImage *)image;
- (NSString *)dateString;
@end
