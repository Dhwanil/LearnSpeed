

#import <UIKit/UIKit.h>

@interface StudentSessionListVC : UITableViewController

@end
