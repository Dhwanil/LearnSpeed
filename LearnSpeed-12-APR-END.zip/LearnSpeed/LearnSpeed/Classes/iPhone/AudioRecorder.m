
#import "AudioRecorder.h"

#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/Audio"]
#define FILEPATH [DOCUMENTS_FOLDER stringByAppendingPathComponent:[self dateString]]

@implementation AudioRecorder

@synthesize lblTime;
@synthesize btnStart;
@synthesize btnpause;
@synthesize btnStop;
@synthesize session, recorder;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.btnStart addTarget:self action:@selector(record) forControlEvents:UIControlStateNormal];
}

- (void)viewDidUnload
{
    [self setLblTime:nil];
    [self setBtnStart:nil];
    [self setBtnpause:nil];
    [self setBtnStop:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSString *)dateString
{
	// return a formatted string for a file name
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	formatter.dateFormat = @"ddMMMYY_hhmmssa";
	return [[formatter stringFromDate:[NSDate date]] stringByAppendingString:@".aif"];
}
- (NSString *) formatTime: (int) num
{
	// return a formatted ellapsed time string
	int secs = num % 60;
	int min = num / 60;
    
	if (num < 60) return [NSString stringWithFormat:@"00:%02d", num];
	return	[NSString stringWithFormat:@"%02d:%02d", min, secs];
}

- (void) updateMeters
{
    [self.lblTime setText:[NSString stringWithFormat:@"%@", [self formatTime:self.recorder.currentTime]]];
}

- (BOOL) startAudioSession
{
	// Prepare the audio session
	NSError *error;
	self.session = [AVAudioSession sharedInstance];
	
	if (![self.session setCategory:AVAudioSessionCategoryPlayAndRecord error:&error])
	{
		NSLog(@"Error: %@", [error localizedDescription]);
		return NO;
	}
	
	if (![self.session setActive:YES error:&error])
	{
		NSLog(@"Error: %@", [error localizedDescription]);
		return NO;
	}
	
	return self.session.inputIsAvailable;
}

- (IBAction)record:(id)sender {
    
    if (![self.recorder isRecording]) {
    
        if (![timer isValid]) {
        
        
    NSError *error;
	
	// Recording settings
	NSMutableDictionary *settings = [NSMutableDictionary dictionary];
	[settings setValue: [NSNumber numberWithInt:kAudioFormatLinearPCM] forKey:AVFormatIDKey];
	[settings setValue: [NSNumber numberWithFloat:8000.0] forKey:AVSampleRateKey];
	[settings setValue: [NSNumber numberWithInt: 1] forKey:AVNumberOfChannelsKey]; // mono
	[settings setValue: [NSNumber numberWithInt:16] forKey:AVLinearPCMBitDepthKey];
	[settings setValue: [NSNumber numberWithBool:NO] forKey:AVLinearPCMIsBigEndianKey];
	[settings setValue: [NSNumber numberWithBool:NO] forKey:AVLinearPCMIsFloatKey];
	
	// File URL
	NSURL *url = [NSURL fileURLWithPath:FILEPATH];
	
	// Create recorder
	self.recorder = [[AVAudioRecorder alloc] initWithURL:url settings:settings error:&error];
	if (!self.recorder)
	{
		NSLog(@"Error: %@", [error localizedDescription]);
        //		return NO;
	}
    
    // Initialize degate, metering, etc.
	self.recorder.delegate = self;
	self.recorder.meteringEnabled = YES;
	
	
	if (![self.recorder prepareToRecord])
	{
		NSLog(@"Error: Prepare to record failed");
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Record" message:@"Error while preparing recording" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alertView show];
        btnStart.userInteractionEnabled = YES;
        //		[ModalAlert say:@"Error while preparing recording"];
        //		return NO;
	}
	
	if (![self.recorder record])
	{
		NSLog(@"Error: Record failed");
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Record" message:@"Error while attempting to record audio" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alertView show];
        btnStart.userInteractionEnabled = YES;
        //		[ModalAlert say:@"Error while attempting to record audio"];
        //		return NO;
	}
	
	// Set a timer to monitor levels, current time
	timer = [NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(updateMeters) userInfo:nil repeats:YES];
            [self.recorder record];
            [self.btnStart setTitle:@"Pause" forState:UIControlStateNormal]; 
        }
        else{
        [self.recorder record];
        [self.btnStart setTitle:@"Pause" forState:UIControlStateNormal];
        }
    }
    else{
        [self.recorder pause];
        [self.btnStart setTitle:@"Record" forState:UIControlStateNormal];
    }
}


- (IBAction)pause:(id)sender {
    
    if ([self.recorder isRecording]) {
        [self.recorder pause];
        [self.btnpause setTitle:@"Continue" forState:UIControlStateNormal];
    }
    else{
        [self.recorder record];
        [self.btnpause setTitle:@"Pause" forState:UIControlStateNormal];
    }
}

- (IBAction)stop:(UIButton*)sender {
    if (sender.tag == 1) {
        isDelete = YES;
        [self.recorder stop];
        btnStart.userInteractionEnabled = YES;
        
    }
    else{
        [self.recorder stop];
        btnStart.userInteractionEnabled = YES;
    }
}

- (IBAction)play:(id)sender {
}

- (void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag
{
	// Stop monitoring levels, time
	[timer invalidate];
    if (isDelete) {
        [self.recorder deleteRecording];
        isDelete = NO;
    }
    else{
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Record" message:[NSString stringWithFormat:@"File saved to %@", [[self.recorder.url path] lastPathComponent]] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alertView show];
    //	self.title = @"Playing back recording...";
	}
	// Start playback
//	AVAudioPlayer *player = [[AVAudioPlayer alloc] initWithContentsOfURL:self.recorder.url error:nil];
//	player.delegate = self;
//	
//	// Change audio session for playback
//	NSError *error;
//	if (![[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:&error])
//	{
//		NSLog(@"Error: %@", [error localizedDescription]);
//		return;
//	}
//    
//	[player play];
    [self.lblTime setText:@"00:00"];
    [self.btnStart setTitle:@"Record" forState:UIControlStateNormal];
}
@end
