
#import "MediaVC.h"
#import "AudioRecorder.h"

#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/Images"]
#define FILEPATH [DOCUMENTS_FOLDER stringByAppendingPathComponent:[self dateString]]

@implementation MediaVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)record:(id)sender {
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Record" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Capture Image", @"Select Image", @"Record Audio", nil];
    [actionSheet showFromTabBar:self.tabBarController.tabBar];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera ]){
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Learn Speed" message:@"Camera Functionality is not available in current device." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            [alert show];
            return;
        }
        else{
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [self presentModalViewController:imagePicker animated:YES];
        }
    }
    else if(buttonIndex == 1){
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentModalViewController:imagePicker animated:YES];
    }
    else if(buttonIndex == 2){
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentModalViewController:imagePicker animated:YES];
    }
    else{
        [actionSheet dismissWithClickedButtonIndex:buttonIndex animated:YES];
    }
}

-(void)storeImageAtDocDir:(UIImage *)image
{
    NSString *strFilepath = FILEPATH;
	NSData *imgData=UIImageJPEGRepresentation(image, 1.0);
	
	if ([imgData writeToFile:strFilepath atomically:YES]) {
		NSLog(@"File is been written successfully")	;
	}
	else {
		NSLog(@"Operation Fail.");
	}	
}
- (NSString *)dateString
{
	// return a formatted string for a file name
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	formatter.dateFormat = @"ddMMMYY_hhmmssa";
	return [[formatter stringFromDate:[NSDate date]] stringByAppendingString:@".png"];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
	UIImage *img1 =[info objectForKey:UIImagePickerControllerOriginalImage];
	[self storeImageAtDocDir:img1];
    //	[self storeImage:img1];
    
    [self dismissModalViewControllerAnimated:YES];
    picker = nil ;
    
	//[[picker parentViewController]dismissModalViewControllerAnimated:YES];
}
-(void)imagePickerControllDidCancel:(UIImagePickerController *)picker
{
    
	[[picker parentViewController]dismissModalViewControllerAnimated:YES];
}
@end
