
#import "CentersCell.h"

@implementation CentersCell

@synthesize lblCenterName, btnCheck;

@end
