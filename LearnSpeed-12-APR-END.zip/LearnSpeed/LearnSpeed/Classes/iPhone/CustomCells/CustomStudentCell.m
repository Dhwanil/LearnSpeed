

#import "CustomStudentCell.h"

@implementation CustomStudentCell

@synthesize firstName,lastName;

@end
