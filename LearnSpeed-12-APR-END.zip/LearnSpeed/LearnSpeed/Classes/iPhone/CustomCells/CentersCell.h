
#import <UIKit/UIKit.h>

@interface CentersCell : UITableViewCell

@property(nonatomic, retain) IBOutlet UIButton *btnCheck;
@property(nonatomic, retain) IBOutlet UILabel *lblCenterName;

@end
