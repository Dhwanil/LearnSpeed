

#import <UIKit/UIKit.h>

@interface StudentSessionCell : UITableViewCell

@property(nonatomic, retain) IBOutlet UILabel *lblDate;
@property(nonatomic, retain) IBOutlet UILabel *lblSessionType;

@end
