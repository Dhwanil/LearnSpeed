
#import "StudentSessionCell.h"

@implementation StudentSessionCell

@synthesize lblDate, lblSessionType;

@end
