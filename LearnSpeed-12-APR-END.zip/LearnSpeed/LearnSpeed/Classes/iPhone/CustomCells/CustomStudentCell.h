
#import <UIKit/UIKit.h>

@interface CustomStudentCell : UITableViewCell

@property(nonatomic, retain) IBOutlet UILabel *firstName;
@property(nonatomic, retain) IBOutlet UILabel *lastName;
@end
