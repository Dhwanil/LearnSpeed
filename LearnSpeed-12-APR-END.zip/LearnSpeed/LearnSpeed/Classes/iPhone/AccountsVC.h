
#import <UIKit/UIKit.h>

@interface AccountsVC : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *btnSignOut;


- (IBAction)signOut:(id)sender;
- (IBAction)openLink:(id)sender;

@end
