
#import <UIKit/UIKit.h>

@interface StudentsVC : UITableViewController{
    
    NSArray *fname, *lname;
}

@end
