
#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController<UITextFieldDelegate>{
    
    NSString *strUserName;
    NSString *strPassword;
}

@property (strong, nonatomic) IBOutlet UITextField *txtUserName;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;

- (IBAction)Login:(id)sender;
- (IBAction)rememberMe:(id)sender;
@end
