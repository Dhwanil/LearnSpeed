
#import <UIKit/UIKit.h>

@interface CentersListVC : UITableViewController

@end
