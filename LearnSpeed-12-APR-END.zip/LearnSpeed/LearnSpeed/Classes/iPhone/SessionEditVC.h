

#import <UIKit/UIKit.h>

@interface SessionEditVC : UIViewController

@property (strong, nonatomic) IBOutlet UIScrollView *scrllView;
@end
